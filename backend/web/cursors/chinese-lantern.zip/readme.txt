﻿=== Chinese Lantern Cursor Set ===

By: AJaxx (http://www.rw-designer.com/user/56600) cyberjack66@yahoo.com

Download: http://www.rw-designer.com/cursor-set/chinese-lantern

Author's description:

A fun and nice cursor set for windows.

Have fun & enjoy!
[[cursor:81696]]

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.