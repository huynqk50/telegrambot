﻿=== Nemesis II - Blue (reloaded) Cursor Set ===

By: AJaxx (http://www.rw-designer.com/user/56600) cyberjack66@yahoo.com

Download: http://www.rw-designer.com/cursor-set/nemesis-ii-blue-reloaded

Author's description:

Special request for Blue. 

This is a Legacy, cursorFX from 2005, converted for windows. Added extra/bonus cursors, animations & alternative colors for user enjoyment.

(See Nemesis II cursor set for credits)
http://www.rw-designer.com/cursor-set/nemesis-ii-reloaded

Have fun & enjoy!
[[cursor:81696]]

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.