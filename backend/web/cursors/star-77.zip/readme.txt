﻿=== Star 77 Cursor Set ===

By: AJaxx (http://www.rw-designer.com/user/56600) cyberjack66@yahoo.com

Download: http://www.rw-designer.com/cursor-set/star-77

Author's description:

A fun cursor set with extra/bonus cursors for user enjoyment. Mix & match until you're satisfied.

*Included a complete set of static cursors, also.

*Credit: 77 star By jani77 

Have fun & enjoy!!
[[cursor:81696]]

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.